# Sarvottam Cables Ltd (NSE: SRVCABLE)
As of: 2026-09-23

## Snapshot
Power-cable, wire and conductor manufacturer. [S-e4dc6442b586]  
Q1 FY27 revenue: ₹1,248 crore, up 18.0%; profit after tax: ₹82 crore, up 5.9% year on year. [S-e4dc6442b586]  
EBITDA margin: 11.2%, down 170 basis points year on year. [S-e4dc6442b586]  
I use the supplied company table over the news article’s conflicting ₹1,428 crore/35% revenue claim. [S-e4dc6442b586] [S-a41e9e2f21c8]

## Bull case
An order book of ₹3,900 crore at June 2026, versus ₹3,150 crore a year earlier, and an export revenue share of 21%, versus 16%, support the growth case. [S-e4dc6442b586]

Management maintains FY27 revenue growth guidance of 15–17%; the company expects Bharuch production in Q3 FY27, adding about 30% to cable capacity. [S-3a36f4ac4109] [S-e4dc6442b586]

Management expects higher copper costs to pass through over the next two quarters; it says about two-thirds of contracts have price-variation clauses with a one-to-two-quarter reset lag. [S-e4dc6442b586] [S-3a36f4ac4109]

Pledged shares were 4.1% of promoter holdings in June 2026, down from 11.5% a year earlier; the 35% figure comes from a March 2024 report and should not describe the current position. [S-32ec5735c356] [S-156eefbe9bcf]

## Bear case
Management reports receivable days rising from 78 to 96, mainly because of two slow-paying state utility customers, while reporting no defaults. [S-3a36f4ac4109]

With ₹620 crore of Bharuch capex about 70% spent and net debt/equity of 0.35 times, collections and the remaining investment warrant scrutiny. [S-3a36f4ac4109]

The ₹46.3 crore GST demand concerns FY2020-21 and FY2021-22 and includes interest and penalty. [S-4a0ebad90ad1]

The company plans an appeal and expects no material impact; that expectation is not proof the demand will be reversed. [S-4a0ebad90ad1]

## Open questions
Will margins and cash conversion improve together?

How quickly can Bharuch reach planned capacity after commissioning? [S-e4dc6442b586]

What are the GST appeal timetable, provisioning treatment and possible cash outflow? [S-4a0ebad90ad1]

What valuation does the share price imply on the research date?

## Sources
Evidence is limited to supplied files; publisher labels and URLs were not independently verified.

- [S-e4dc6442b586] ir_press_release_2026-08-08.md — Sarvottam Cables Ltd, investor relations (company press release); 2026-08-08.
- [S-a41e9e2f21c8] businessdaily_2026-08-09.md — Business Daily Online (news website); 2026-08-09.
- [S-3a36f4ac4109] ir_concall_2026-08-11.md — Q1 FY27 earnings call transcript (excerpt), hosted on company IR site; 2026-08-11.
- [S-32ec5735c356] nse_shareholding_2026-07-15.md — NSE shareholding pattern filing (summary); 2026-07-15.
- [S-156eefbe9bcf] marketwatchindia_2024-03-18.md — Market Watch India (news website); 2024-03-18.
- [S-4a0ebad90ad1] nse_announcement_2026-09-02.md — NSE corporate announcement (company disclosure); 2026-09-02.