# Sarvottam Cables Ltd (NSE: SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables Ltd (NSE: SRVCABLE) manufactures power cables, wires and conductors. [S-e4dc6442b586]  
Q1 FY27, ended 30 June 2026: consolidated revenue was ₹1,248 crore, up 18.0% YoY. [S-e4dc6442b586]  
Reported profit after tax (PAT) rose 5.9% to ₹82 crore. [S-e4dc6442b586]  
EBITDA margin fell 170 basis points to 11.2%. [S-e4dc6442b586]

## Bull case

Order book reached ₹3,900 crore at 30 June 2026, versus ₹3,150 crore a year earlier. [S-e4dc6442b586] In August, management maintained FY27 revenue-growth guidance of 15–17%. [S-3a36f4ac4109] Management’s August plan targeted Bharuch production in Q3 FY27, adding about 30% to cable capacity. [S-e4dc6442b586] The backlog and capacity plan could support higher sales if orders convert and commissioning succeeds. [S-e4dc6442b586]

At 30 June 2026, 4.1% of promoter holdings were pledged, versus 11.5% in June 2025. [S-32ec5735c356] The March 2024 article’s 35% pledge figure is historical. [S-156eefbe9bcf]

## Bear case

Management says about two-thirds of contracts have price-variation clauses that reset with a lag of one to two quarters. [S-3a36f4ac4109] This can delay margin recovery. [S-3a36f4ac4109] The CFO reported receivable days rising from 78 to 96 over the preceding year, mainly due to two state utilities, with no defaults observed. [S-3a36f4ac4109] Slower collections could constrain cash during Bharuch’s ₹620 crore expansion, which the CFO reported about 70% spent. [S-3a36f4ac4109] The CFO said funding is mainly internal accruals plus some term debt, and reported company net debt to equity of 0.35 times. [S-3a36f4ac4109]

The September disclosure reports a ₹46.3 crore GST demand, including interest and penalty, for FY2020-21/FY2021-22. [S-4a0ebad90ad1] Management intends to appeal and expects no material impact; this remains its assessment. [S-4a0ebad90ad1] The demand is roughly 56% of Q1 FY27 PAT; the eventual cash impact remains unestablished. [S-4a0ebad90ad1] [S-e4dc6442b586]

Business Daily reports revenue of ₹1,428 crore/+35%, conflicting with the company table’s ₹1,248 crore/+18%; the direct comparative table is stronger supplied evidence for results. [S-a41e9e2f21c8] [S-e4dc6442b586]

## Open questions

- Has a GST appeal been filed, and what deposit or accounting provision may be required? [S-4a0ebad90ad1]
- Are utility collections improving, and what does operating cash flow show? [S-3a36f4ac4109]
- Will Bharuch meet its Q3 FY27 target, and what valuation does the current share price imply? [S-e4dc6442b586]

## Sources

Publisher labels and dates below are supplied metadata, without external authentication.

- [S-e4dc6442b586] `ir_press_release_2026-08-08.md` — Sarvottam Cables Ltd, investor relations (company press release); 2026-08-08.
- [S-3a36f4ac4109] `ir_concall_2026-08-11.md` — Q1 FY27 earnings call transcript (excerpt), hosted on company IR site; 2026-08-11.
- [S-32ec5735c356] `nse_shareholding_2026-07-15.md` — NSE shareholding pattern filing (summary); 2026-07-15.
- [S-156eefbe9bcf] `marketwatchindia_2024-03-18.md` — Market Watch India (news website); 2024-03-18.
- [S-4a0ebad90ad1] `nse_announcement_2026-09-02.md` — NSE corporate announcement (company disclosure); 2026-09-02.
- [S-a41e9e2f21c8] `businessdaily_2026-08-09.md` — Business Daily Online (news website); 2026-08-09.