# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables Ltd manufactures power cables, wires and conductors. [S03]
Revenue from operations rose to ₹1,248 crore, an 18.0% increase YoY. [S03]
EBITDA margin fell to 11.2%, down 170 basis points from 12.9%. [S03]

## Bull case

- Management maintains FY27 revenue growth guidance of 15 to 17 percent. [S02]
- The new Bharuch plant, adding about 30% to capacity, is expected to begin commercial production in Q3 FY27. [S03]
- The company expects to pass on copper price increases to customers over the next two quarters. [S03]

## Bear case

- Operating margins fell to 11.2%, down 170 basis points from 12.9%. [S03]
- Receivable days rose from 78 to 96, largely due to two large state utility customers. [S02]
- The company received a ₹46.3 crore GST demand, but management says it will not materially impact operations. [S07]

## Open questions

- Will the company be able to pass on copper price increases to customers over the next two quarters? [S03]
- What impact will the ₹46.3 crore GST demand have on the company's financial position? [S07]

## Sources

- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
