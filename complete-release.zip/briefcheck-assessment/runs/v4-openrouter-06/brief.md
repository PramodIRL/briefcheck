# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables Ltd manufactures power cables, wires, and conductors. [S03]
Revenue from operations grew 18.0% YoY to ₹1,248 crore, while profit after tax rose 5.9% to ₹82 crore in Q1 FY27. [S03]
EBITDA margin contracted by 170 basis points to 11.2% due to rising copper costs. [S01] [S03]

## Bull case

- Management maintains FY27 revenue growth guidance of 15–17% and plans to double data-centre cable revenue share from 9% within two years. [S02] [S03]
- The new Bharuch plant is planned to add 30% capacity with commercial production expected to start in Q3 FY27, and management states it is funded mainly through internal accruals and some term debt. [S02] [S03]
- Management notes that two-thirds of contracts include price-variation clauses, which they expect to pass on higher copper costs to customers over the next two quarters. [S02] [S03]

## Bear case

- Receivable days increased from 78 to 96 over the last year, driven by slower payments from two large state utility customers, though no defaults have been reported. [S02] [S03]
- The company received a GST demand order of ₹46.3 crore (including interest and penalty) for input tax credit claimed in FY2020-21 and FY2021-22, and management believes it has a strong case on merits based on legal advice and intends to file an appeal. [S07]
- Promoter pledging remains a structural risk, with 4.1% of promoter shares pledged as of June 2026, down from 11.5% a year ago but still elevated compared to historical lows. [S04] [S08]

## Open questions

- How effective will the price-variation clauses be in recovering copper cost increases, given the one-to-two-quarter lag, and can margins stabilize if copper prices remain elevated? [S02] [S03]
- Can the data-centre cable segment double its revenue share from 9% within two years as management expects, and what is the competitive risk if larger incumbents enter this niche? [S02] [S03]

## Sources

- [S01] businessdaily_2026-08-09.md | Business Daily Online (news website) | 2026-08-09 | https://businessdaily.example/markets/sarvottam-cables-q1-results
- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S04] marketwatchindia_2024-03-18.md | Market Watch India (news website) | 2024-03-18 | https://marketwatchindia.example/2024/03/sarvottam-promoter-pledge
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
- [S08] nse_shareholding_2026-07-15.md | NSE shareholding pattern filing (summary) | 2026-07-15 | https://nse.example/shareholding/SRVCABLE/2026-06
